import queryResolvers from "./query";


const resolverIndex = {
    ...queryResolvers
}

export default resolverIndex;